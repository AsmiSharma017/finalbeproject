const express = require('express');
const path = require('path');
const fs = require('fs');

const router = express.Router();

// ✅ Serve index.html on root URL
router.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, '../public/index.html'));
});

// ✅ Serve other HTML pages
router.get('/login', (req, res) => res.sendFile(path.join(__dirname, '../public/login.html')));
router.get('/user', (req, res) => res.sendFile(path.join(__dirname, '../public/user.html')));
router.get('/bmi', (req, res) => res.sendFile(path.join(__dirname, '../public/bmi.html')));
router.get('/checkout', (req, res) => res.sendFile(path.join(__dirname, '../public/checkout.html')));
router.get('/contact', (req, res) => res.sendFile(path.join(__dirname, '../public/contact.html')));
router.get('/register', (req, res) => res.sendFile(path.join(__dirname, '../public/register.html')));
router.get('/register', (req, res) => res.sendFile(path.join(__dirname, '../public/preferences.html')));
router.get('/register', (req, res) => res.sendFile(path.join(__dirname, '../public/trainer.html')));

// ✅ Handle login authentication
router.post('/login', (req, res) => {
    const { username, password } = req.body;

    fs.readFile(path.join(__dirname, '../models/users.json'), 'utf-8', (err, data) => {
        if (err) return res.status(500).send("Server Error");

        const users = JSON.parse(data);
        const user = users.find(u => u.username === username && u.password === password);

        if (user) {
            return res.status(302).redirect('/user');
        } else {
            return res.status(302).redirect('/register');
        }
    });
});

// ✅ Handle user registration
router.post('/register', (req, res) => {
    const { username, email, password } = req.body;

    // Read existing users from JSON file
    fs.readFile(path.join(__dirname, '../models/users.json'), 'utf-8', (err, data) => {
        if (err) return res.status(500).send("Server Error");

        const users = JSON.parse(data);

        // Check if user already exists
        if (users.find(u => u.username === username || u.email === email)) {
            return res.status(400).send("User already exists!");
        }

        // Add new user
        users.push({ username, email, password });

        // Write updated users back to the JSON file
        fs.writeFile(path.join(__dirname, '../models/users.json'), JSON.stringify(users, null, 2), (err) => {
            if (err) return res.status(500).send("Error saving user");
            return res.status(201).redirect('/login'); // Redirect to login after successful registration
        });
    });
});

module.exports = router;
