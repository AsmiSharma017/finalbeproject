const express = require('express');
const path = require('path');
const apiRoutes = require('./routes/apiRoutes');
const logger = require('./middlewares/logger');
const errorHandler = require('./middlewares/errorHandler');
const helmet = require('helmet');
const morgan = require('morgan');
const cors = require('cors');
const compression = require('compression');
const cookieParser = require('cookie-parser');
const bodyParser = require('body-parser');

const app = express();

// ✅ Apply middlewares globally
app.use((req, res, next) => {
    console.log("✅ Logger middleware applied");
    logger(req, res, next);
});

app.use((req, res, next) => {
    console.log("✅ Helmet middleware applied");
    helmet()(req, res, next);
});

app.use((req, res, next) => {
    console.log("✅ Morgan middleware applied");
    morgan('dev')(req, res, next);
});

app.use((req, res, next) => {
    console.log("✅ CORS middleware applied");
    cors()(req, res, next);
});

app.use((req, res, next) => {
    console.log("✅ Compression middleware applied");
    compression()(req, res, next);
});

app.use((req, res, next) => {
    console.log("✅ CookieParser middleware applied");
    cookieParser()(req, res, next);
});

app.use((req, res, next) => {
    console.log("✅ BodyParser (JSON) middleware applied");
    bodyParser.json()(req, res, next);
});

app.use((req, res, next) => {
    console.log("✅ BodyParser (URL Encoded) middleware applied");
    bodyParser.urlencoded({ extended: true })(req, res, next);
});

// ✅ Serve static files
app.use((req, res, next) => {
    console.log("✅ Serving static files middleware applied");
    express.static(path.join(__dirname, 'public'))(req, res, next);
});

// ✅ API Routes
app.use((req, res, next) => {
    console.log("✅ API Routes  applied");
    apiRoutes(req, res, next);
});

// ✅ Error handling middleware (must be after routes)
app.use((err, req, res, next) => {
    console.log("❌ Error Handler middleware applied");
    errorHandler(err, req, res, next);
});

app.listen(8080, () => {
    console.log('🚀 Server running on http://localhost:8080');
});
